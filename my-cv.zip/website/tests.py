from django.test import TestCase

def Index_page(request):
    return render(request,'salam')

